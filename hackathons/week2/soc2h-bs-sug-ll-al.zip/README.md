## TEAM MEMBERS

Anusha Lihala; https://github.com/anushalihala

Lisa Liu; https://github.com/lisaisfabu

Solange Umuhire Gasengayire; https://github.com/SolangeUG

## Files
main.py

dictionary.py

trienode.py

score.py

board.py

boggle-dictionary.txt

### Please execute main.py

